#ifndef FORMS_H_INCLUDED
#define FORMS_H_INCLUDED

#include "geometry.h"
#include "animation.h"


class Color{
public:
    float r, g, b;
    Color(float rr = 1.0f, float gg = 1.0f, float bb = 1.0f) {r=rr; g=gg; b=bb;}
};

// Constant Colors
const Color RED(1.0f, 0.0f, 0.0f);
const Color BLUE(0.0f, 0.49f, 1.0f);
const Color GREEN(0.03f, 0.32f, 0.15f);
const Color YELLOW(1.0f, 0.86f, 0.07f);
const Color WHITE(1.0f, 1.0f, 1.0f);
const Color AMETHYSTE(0.53f,0.31f,0.65f);
const Color BURGUNDY(0.42f,0.02f,0.1f);
const Color PARROT_GREEN(0.22f,0.94f,0.29f);
const Color ZINZOLIN(0.42f,0.0f,0.46f);
const Color CAPUCINE(1.0f,0.36f,0.3f);
const Color OCEAN(0.1f,0.0f,0.6f);

// Generic class to render and animate an object
class Form{
protected:
    Color col;
    Animation anim;
public:
    Animation& getAnim() {return anim;}
    void setAnim(Animation ani) {anim = ani;}
    // This method should update the anim object with the corresponding physical model
    // It has to be done in each inherited class, otherwise all forms will have the same movements !
    // Virtual method for dynamic function call
    // Pure virtual to ensure all objects have their physics implemented
    virtual void update(double delta_t) = 0;
    // Virtual method : Form is a generic type, only setting color and reference position
    virtual void render();
};


class Goutte : public Form{
private:
    Vector vdir1;
    double rayon;
    Point centre;
    double hauteur;
    bool chute;
public:
    // Constructeur
    Goutte(Vector v1 = Vector(1,0,0), double r = 1.0, double l = 1.0, bool c = 0,Point org = Point(),Color cl = Color());

    //Constructeur de copie
    Goutte(Goutte *goutteACopier);

    // Destructeur
    ~Goutte();
    // Fonction OPENGL
    void update(double delta_t);
    void render();
    // GET & SETTERS
    void setHauteur(double h) {
        hauteur += h;
        getAnim().setPos(centre);
    }
    double getHauteur(){return hauteur;}
    void setRayon(double r) {
        rayon += r;
        getAnim().setPos(centre);
    }
    double getRayon(){return rayon;}
    void setCentre(double y) {
        centre.y += y;
        getAnim().setPos(centre);
    }
    Point getCentre(){return centre;}
    bool getChute(){return chute;}
    void setChute(bool c){chute=c;}
    Color getColor(){return col;}
};


// A Plan
class Plan : public Form{
private:
    Vector vdir1,vdir2;
    Point org;
    Point tabPlan_1[50][50];
    Point tabPlan_2[50][50];
    Point tabPlan_3[50][50];
    Point tabPlan_4[50][50];
    bool marqueur_colli;
    Goutte *impact;
public:
    void setColor(Color c){col = c;}
    Plan(Vector v1 = Vector(1,0,0),Vector v2 = Vector(0,0,1), Point org = Point(),
          Color cl = Color(), bool m_colli = false, Goutte *imp = NULL);
    void update(double delta_t);
    void render();
    bool collision(Goutte* goutte);
    double Vague(double dist);
    void setColliMarqueur(bool colli){marqueur_colli = colli;}
    void setImpact(Goutte* goutte){impact = goutte;}

};
#endif // FORMS_H_INCLUDED
