#include <cmath>
#include <SDL2/SDL_opengl.h>
#include <GL/GLU.h>
#include "forms.h"
#include "geometry.h"

#define pi 3.14159265359

using namespace std;

void Form::update(double delta_t){
    // Nothing to do here, animation update is done in child class method
}


void Form::render(){
    // Point of view for rendering
    // Common for all Forms
    Point org = anim.getPos();
    glTranslated(org.x, org.y, org.z);
    glColor3f(col.r, col.g, col.b);
}


// Constructeur
Goutte::Goutte(Vector v1, double r, double h,bool c,Point org, Color cl){
    vdir1 = v1;
    hauteur=h;
    rayon=r;
    chute = c;
    centre = org;
    anim.setPos(centre);
    col=cl;
}

// Destructeur
Goutte::~Goutte(){
}

//Constructeur de copie
/*Goutte::Goutte(Goutte const& goutteACopier)
    : vdir1(goutteACopier.vdir1), rayon(goutteACopier.rayon),
    centre(goutteACopier.centre), hauteur(goutteACopier.hauteur),
    chute(goutteACopier.chute){
        vdir1 = new vdir1(*(goutteACopier.vdir1));
        rayon = new rayon(*(goutteACopier.rayon));
        centre = new centre(*(goutteACopier.centre));
        hauteur = new hauteur(*(goutteACopier.hauteur));
        chute = new chute(*(goutteACopier.chute));
}*/

void Goutte::update(double delta_t){
    Vector accel = getAnim().getAccel();
    Point position = getAnim().getPos();

    Vector delta_vit=integrate(accel,delta_t);
    Vector vitesse = delta_vit + getAnim().getSpeed();
    Vector delta_posi=integrate(vitesse,delta_t);
    position.translate(delta_posi);

    getAnim().setSpeed(vitesse);
    Goutte::centre = position;
    getAnim().setPos(position);
}


void Goutte::render(){
    Form::render();

    glColor4f(col.r, col.g, col.b, 0.5f);

//Cone
    glBegin(GL_TRIANGLE_FAN);
    glVertex3f(0, hauteur, 0);
    for (int angle = 0; angle < 360; angle+=1)
    {
        glVertex3d(sin(angle) * rayon, 0, cos(angle) * rayon);
    }
    glEnd();

//Cr�ation de la demi-sph�re
    double equ_plan0[] = {0, -1, 0, 0};
    glClipPlane(GL_CLIP_PLANE0, equ_plan0);
    glEnable(GL_CLIP_PLANE0);
    GLUquadric *quad;
    quad = gluNewQuadric();
    gluSphere(quad, rayon, 50, 50);
    glDisable(GL_CLIP_PLANE0);
    gluDeleteQuadric(quad);
}

Plan::Plan(Vector v1,Vector v2,Point origin, Color cl, bool m_colli, Goutte* imp){
    vdir1 = v1;
    vdir2 = v2;
    org = origin;
    col = cl;
    marqueur_colli = m_colli;
    impact = imp;
    for(int i=0; i<50; i++){
        for(int j=0; j<50; j++){
            Point point = Point(i+org.x,org.y,j+org.z);
            tabPlan_1[i][j] = point;

            point = Point(-i+org.x,org.y,j+org.z);
            tabPlan_2[i][j] = point;

            point = Point(i+org.x,org.y,-j+org.z);
            tabPlan_3[i][j] = point;

            point = Point(-i+org.x,org.y,-j+org.z);
            tabPlan_4[i][j] = point;
        }
    }
}

void Plan::update(double delta_t){
    if(marqueur_colli == true){
        for(int i=0; i<50; i++){
            for(int j=0; j<50; j++){
                Point position = getAnim().getPos();
                double dista = distance_1(impact->getCentre(), tabPlan_1[i][j]);
                Vector delta_posi = Vector(tabPlan_1[i][j], Point(tabPlan_1[i][j].x, tabPlan_1[i][j].y + Vague(dista), tabPlan_1[i][j].z));
                //tabPlan_1[i][j].y = Vague(dista);

                position.translate(delta_posi);
                tabPlan_1[i][j].y = position.y;

                //getAnim().setPos(position);


                dista = distance_1(impact->getCentre(), tabPlan_2[i][j]);
                delta_posi = Vector(tabPlan_2[i][j], Point(tabPlan_2[i][j].x, tabPlan_2[i][j].y + Vague(dista), tabPlan_2[i][j].z));
                //tabPlan_1[i][j].y = Vague(dista);

                position.translate(delta_posi);
                tabPlan_2[i][j].y = position.y;

                dista = distance_1(impact->getCentre(), tabPlan_3[i][j]);
                delta_posi = Vector(tabPlan_3[i][j], Point(tabPlan_3[i][j].x, tabPlan_3[i][j].y + Vague(dista), tabPlan_3[i][j].z));
                //tabPlan_1[i][j].y = Vague(dista);

                position.translate(delta_posi);
                tabPlan_3[i][j].y = position.y;


                dista = distance_1(impact->getCentre(), tabPlan_4[i][j]);
                delta_posi = Vector(tabPlan_4[i][j], Point(tabPlan_4[i][j].x, tabPlan_4[i][j].y + Vague(dista), tabPlan_4[i][j].z));
                //tabPlan_1[i][j].y = Vague(dista);

                position.translate(delta_posi);
                tabPlan_4[i][j].y = position.y;
            }
        }
    }
}

void Plan::render(){
    Form::render();
    for(int i=0; i<50; i++){
        for(int j=0; j<50; j++){
            Point p1 = Point(tabPlan_1[i][j].x,tabPlan_1[i][j].y,tabPlan_1[i][j].z);
            Point p2 = p1, p3, p4 = p1;
            p2.translate(vdir1);
            p3 = p2;
            p3.translate(vdir2);
            p4.translate(vdir2);

            Form::render();
            glBegin(GL_QUADS);
            {
                if(impact!=NULL)
                {
                    glColor3f(impact->getColor().r, impact->getColor().g, impact->getColor().b);
                }else
                {
                    glColor3f(col.r, col.g, col.b);
                }
                glVertex3d(0.08*p1.x, 0.08*p1.y, 0.08*p1.z);
                glVertex3d(0.08*p2.x, 0.08*p2.y, 0.08*p2.z);
                glVertex3d(0.08*p3.x, 0.08*p3.y, 0.08*p3.z);
                glVertex3d(0.08*p4.x, 0.08*p4.y, 0.08*p4.z);
            }


            p1 = Point(tabPlan_2[i][j].x,tabPlan_2[i][j].y,tabPlan_2[i][j].z);
            p2 = p1, p3, p4 = p1;
            p2.translate(-vdir1);
            p3 = p2;
            p3.translate(vdir2);
            p4.translate(vdir2);

            Form::render();
            glBegin(GL_QUADS);
            {
                if(impact!=NULL)
                {
                    glColor3f(impact->getColor().r, impact->getColor().g, impact->getColor().b);
                }else
                {
                    glColor3f(col.r, col.g, col.b);
                }
                glVertex3d(0.08*p1.x, 0.08*p1.y, 0.08*p1.z);
                glVertex3d(0.08*p2.x, 0.08*p2.y, 0.08*p2.z);
                glVertex3d(0.08*p3.x, 0.08*p3.y, 0.08*p3.z);
                glVertex3d(0.08*p4.x, 0.08*p4.y, 0.08*p4.z);
            }

            p1 = Point(tabPlan_3[i][j].x,tabPlan_3[i][j].y,tabPlan_3[i][j].z);
            p2 = p1, p3, p4 = p1;
            p2.translate(vdir1);
            p3 = p2;
            p3.translate(-vdir2);
            p4.translate(-vdir2);

            Form::render();
            glBegin(GL_QUADS);
            {
                if(impact!=NULL)
                {
                    glColor3f(impact->getColor().r, impact->getColor().g, impact->getColor().b);
                }else
                {
                    glColor3f(col.r, col.g, col.b);
                }
                glVertex3d(0.08*p1.x, 0.08*p1.y, 0.08*p1.z);
                glVertex3d(0.08*p2.x, 0.08*p2.y, 0.08*p2.z);
                glVertex3d(0.08*p3.x, 0.08*p3.y, 0.08*p3.z);
                glVertex3d(0.08*p4.x, 0.08*p4.y, 0.08*p4.z);
            }

            p1 = Point(tabPlan_4[i][j].x,tabPlan_4[i][j].y,tabPlan_4[i][j].z);
            p2 = p1, p3, p4 = p1;
            p2.translate(-vdir1);
            p3 = p2;
            p3.translate(-vdir2);
            p4.translate(-vdir2);

            Form::render();
            glBegin(GL_QUADS);
            {
                if(impact!=NULL)
                {
                    glColor3f(impact->getColor().r, impact->getColor().g, impact->getColor().b);
                }else
                {
                    glColor3f(col.r, col.g, col.b);
                }
                glVertex3d(0.08*p1.x, 0.08*p1.y, 0.08*p1.z);
                glVertex3d(0.08*p2.x, 0.08*p2.y, 0.08*p2.z);
                glVertex3d(0.08*p3.x, 0.08*p3.y, 0.08*p3.z);
                glVertex3d(0.08*p4.x, 0.08*p4.y, 0.08*p4.z);
            }


            glEnd();
        }
    }
}

bool Plan::collision(Goutte* goutte){ //� modifier lors de l'integration de l'eau
    bool colli = false;
    double dist = 0;

    Point P=Point(goutte->getCentre().x, org.y, goutte->getCentre().z);

    dist = distance_1(P,goutte->getCentre());
    //std::cout << dist;
    if(dist <= goutte->getRayon()) colli = true;

    return colli;
}

double Plan::Vague(double dist){
    double g = 9.81;
    double masse_goutte = 0.034;
    double masse_volumique = 1;
    double longueur_onde = 0.02;
    double diam_goutte = 2.6;

    double coef_reduc = 1;

    double distance_goutte_plan = dist;

    double Amplitude = coef_reduc * sqrt((impact->getHauteur() * masse_goutte)/(masse_volumique*g*pi));
    double Vitesse_propagation = sqrt(((g*longueur_onde)/2*pi));
    double Frequence = Vitesse_propagation / distance_goutte_plan;

    double nouvY;
    nouvY = Amplitude*1000 * (sin(distance_goutte_plan)/(distance_goutte_plan));

    //std::cout << nouvY << endl;

    if(nouvY > 10) nouvY = 10;
    if(nouvY < 0.1 && nouvY > -0.1) nouvY = 0;
    return nouvY;
}
