// Using SDL, SDL OpenGL and standard IO
#include <iostream>
#include <cmath>
#include <SDL2/SDL.h>
#include <SDL2/SDL_opengl.h>
#include <GL/GLU.h>
#include <windows.h>

// Module for space geometry
#include "geometry.h"
// Module for generating and rendering forms
#include "forms.h"


using namespace std;


/***************************************************************************/
/* Constants and functions declarations                                    */
/***************************************************************************/
// Screen dimension constants
const int SCREEN_WIDTH = 1000;
const int SCREEN_HEIGHT = 800;

// Max number of forms : static allocation
const int MAX_FORMS_NUMBER = 40;
const int MAX_COLORS_NUMBER = 10;

// Angle pour la camera
double angleX = 0;
double angleY = 0;
double angleZ = 0;
double zoomZ = -21;

// Position de la goutte de base
double posX=0;
double posY=1;
double posZ=0;

// Liste des couleurs de goutte
Color Color[MAX_COLORS_NUMBER]={BLUE,RED,YELLOW,CAPUCINE,GREEN,WHITE,AMETHYSTE,BURGUNDY,PARROT_GREEN,ZINZOLIN};
int idColor=0;

// Animation actualization delay (in ms) => 100 updates per second
const Uint32 ANIM_DELAY = 10;


// Starts up SDL, creates window, and initializes OpenGL
bool init(SDL_Window** window, SDL_GLContext* context);

// Initializes matrices and clear color
bool initGL();

// Updating forms for animation
void update(Form* formlist[MAX_FORMS_NUMBER], double delta_t);

// Renders scene to the screen
const void render(Form* formlist[MAX_FORMS_NUMBER], const Point &cam_pos);

// Frees media and shuts down SDL
void close(SDL_Window** window);


/***************************************************************************/
/* Functions implementations                                               */
/***************************************************************************/
bool init(SDL_Window** window, SDL_GLContext* context)
{
    // Initialization flag
    bool success = true;

    // Initialize SDL
    if(SDL_Init(SDL_INIT_VIDEO) < 0)
    {
        cout << "SDL could not initialize! SDL Error: " << SDL_GetError() << endl;
        success = false;
    }
    else
    {
        // Use OpenGL 2.1
        SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 2);
        SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 1);

        // Create window
        *window = SDL_CreateWindow( "TP intro OpenGL / SDL 2", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_OPENGL | SDL_WINDOW_SHOWN );
        if( *window == NULL )
        {
            cout << "Window could not be created! SDL Error: " << SDL_GetError() << endl;
            success = false;
        }
        else
        {
            // Create context
            *context = SDL_GL_CreateContext(*window);
            if( *context == NULL )
            {
                cout << "OpenGL context could not be created! SDL Error: " << SDL_GetError() << endl;
                success = false;
            }
            else
            {
                // Use Vsync
                if(SDL_GL_SetSwapInterval(1) < 0)
                {
                    cout << "Warning: Unable to set VSync! SDL Error: " << SDL_GetError() << endl;
                }

                // Initialize OpenGL
                if( !initGL() )
                {
                    cout << "Unable to initialize OpenGL!"  << endl;
                    success = false;
                }
            }
        }
    }

    //Controle de la transparence
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    return success;
}


bool initGL()
{
    bool success = true;
    GLenum error = GL_NO_ERROR;

    // Initialize Projection Matrix
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

    // Set the viewport : use all the window to display the rendered scene
    glViewport(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);

    // Fix aspect ratio and depth clipping planes
    gluPerspective(40.0, (GLdouble)SCREEN_WIDTH/SCREEN_HEIGHT, 1.0, 100.0);


    // Initialize Modelview Matrix
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    // Initialize clear color : black with no transparency
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f );

    // Activate Z-Buffer


    // Check for error
    error = glGetError();
    if( error != GL_NO_ERROR )
    {
        cout << "Error initializing OpenGL!  " << gluErrorString( error ) << endl;
        success = false;
    }

    glEnable(GL_DEPTH_TEST);

    return success;
}

void update(Form* formlist[MAX_FORMS_NUMBER], double delta_t)
{
    // Update the list of forms
    unsigned short i = 0;
    while(formlist[i] != NULL)
    {
        formlist[i]->update(delta_t);
        i++;
    }
}

const void render(Form* formlist[MAX_FORMS_NUMBER], const Point &cam_pos)
{
    // Clear color buffer and Z-Buffer
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // Initialize Modelview Matrix
    glMatrixMode( GL_MODELVIEW );
    glLoadIdentity();

    // Set the camera position and parameters
    gluLookAt(cam_pos.x,cam_pos.y,cam_pos.z, 0.0,0.0,0.0, 0.0,1.0,0.0);

    // Isometric view
    glTranslated(0,0,zoomZ);
    glRotated(-45, 0, 1, 0);
    glRotated(30, 1, 0, -1);

    glRotated(angleX,1,0,0);
    glRotated(angleY,0,1,0);
    glRotated(angleZ,0,0,1);

    // X, Y and Z axis
    glPushMatrix(); // Preserve the camera viewing point for further forms
    // Render the coordinates system
    glBegin(GL_LINES);
    {
        glColor3f(1.0f, 0.0f, 0.0f);
        glVertex3i(0, 0, 0);
        glVertex3i(1, 0, 0);
        glColor3f(0.0f, 1.0f, 0.0f);
        glVertex3i(0, 0, 0);
        glVertex3i(0, 1, 0);
        glColor3f(0.0f, 0.0f, 1.0f);
        glVertex3i(0, 0, 0);
        glVertex3i(0, 0, 1);
    }
    glEnd();
    glPopMatrix(); // Restore the camera viewing point for next object

    // Render the list of forms
    unsigned short i = 0;
    while(formlist[i] != NULL)
    {
        glPushMatrix(); // Preserve the camera viewing point for further forms
        formlist[i]->render();
        glPopMatrix(); // Restore the camera viewing point for next object
        i++;
    }
}

void close(SDL_Window** window)
{
    //Destroy window
    SDL_DestroyWindow(*window);
    *window = NULL;

    //Quit SDL subsystems
    SDL_Quit();
}


void changerTaille(Goutte goutte, bool sens){

}


/***************************************************************************/
/* MAIN Function                                                           */
/***************************************************************************/
int main(int argc, char* args[])
{
    // The window we'll be rendering to
    SDL_Window* gWindow = NULL;

    // OpenGL context
    SDL_GLContext gContext;


    // Start up SDL and create window
    if( !init(&gWindow, &gContext))
    {
        cout << "Failed to initialize!" << endl;
    }
    else
    {
        // Main loop flag
        bool quit = false;
        Uint32 current_time, previous_time, elapsed_time;

        // Event handler
        SDL_Event event;

        // Camera position
        Point camera_position(0, 0.0, 5.0);

        // The forms to render
        Form* forms_list[MAX_FORMS_NUMBER];
        Goutte* gouttes_list[MAX_FORMS_NUMBER];
        unsigned short number_of_forms = 0, i, number_of_gouttes = 0;

        for (i=0; i<MAX_FORMS_NUMBER; i++)
        {
            forms_list[i] = NULL;
            gouttes_list[i] = NULL;
        }
        // Create here specific forms and add them to the list...
        // Don't forget to update the actual number_of_forms !
        Plan *plan = NULL;
        plan = new Plan(Vector(1,0,0), Vector(0,0,1), Point(0, 0, 0), OCEAN);
        forms_list[number_of_forms] = plan;
        number_of_forms++;

        // Get first "current time"
        previous_time = SDL_GetTicks();
        // While application is running

        while(!quit)
        {
            // Handle events on queue
            while(SDL_PollEvent(&event) != 0)
            {
                int x = 0, y = 0;
                SDL_Keycode key_pressed = event.key.keysym.sym;

                switch(event.type)
                {
                // User requests quit
                case SDL_QUIT:
                    quit = true;
                    break;
                case SDL_KEYDOWN:
                    // Handle key pressed with current mouse position
                    SDL_GetMouseState( &x, &y );

                    switch(key_pressed)
                    {
                    // Cr�er une goutte d'eau
                    case SDLK_1:
                    {
                        Goutte *goutte1=NULL;
                        goutte1=new Goutte(Vector(0,0,1), 0.25, 0.45,0, Point(posX,posY,posZ), Color[idColor]);
                        // On incr�mente l'idColor pour changer de color, et on revient � 0 pour ne pas d�passer le tableau de Color
                        idColor++;
                        idColor = idColor%MAX_COLORS_NUMBER;
                        forms_list[number_of_forms] = goutte1;
                        gouttes_list[number_of_gouttes] = goutte1;
                        number_of_forms++;
                        number_of_gouttes++;
                    }break;

                    // Chute de la goutte d'eau
                    case SDLK_SPACE:
                        if(number_of_gouttes == 0)
                            break;

                        gouttes_list[number_of_gouttes-1]->getAnim().setAccel(Vector(0,-9.8,0));
                        gouttes_list[number_of_gouttes-1]->setChute(1);

                        break;

                    // On modifie la hauteur de la goutte avec les touches UP et DOWN
                    case SDLK_UP:
                        if(number_of_gouttes == 0)
                            break;
                        gouttes_list[number_of_gouttes-1]->setCentre(0.5);
                        break;
                    case SDLK_DOWN:
                        if(number_of_gouttes == 0)
                            break;
                        gouttes_list[number_of_gouttes-1]->setCentre(-0.01);
                        break;

                    // On modifie la taille de la goutte avec les touches LEFT et RIGHT
                    case SDLK_LEFT:
                        if(number_of_gouttes == 0)
                            break;
                        gouttes_list[number_of_gouttes-1]->setRayon(-0.05);
                        gouttes_list[number_of_gouttes-1]->setHauteur(-0.05);
                        break;
                    case SDLK_RIGHT:
                        if(number_of_gouttes == 0)
                            break;
                        gouttes_list[number_of_gouttes-1]->setRayon(0.05);
                        gouttes_list[number_of_gouttes-1]->setHauteur(0.05);
                        break;

                    // On bouge la cam�ra selon l'axe X avec 2 et 5 du pav� num�rique
                    case SDLK_KP_2:
                        angleX -= 3;
                        break;
                    case SDLK_KP_5:
                        angleX += 3;
                        break;

                    // On bouge la cam�ra selon l'axe Y avec 1 et 3 du pav� num�rique
                    case SDLK_KP_1:
                        angleY -= 3;
                        break;
                    case SDLK_KP_3:
                        angleY += 3;
                        break;

                    // On bouge la cam�ra selon l'axe Z avec 4 et 6 du pav� num�rique
                    case SDLK_KP_4:
                        angleZ -= 3;
                        break;
                    case SDLK_KP_6:
                        angleZ += 3;
                        break;

                    // On zoom avec + et -
                    case SDLK_KP_PLUS:
                        zoomZ += 3;
                        break;
                    case SDLK_KP_MINUS:
                        zoomZ -= 3;
                        break;

                    // Quit the program when 'q' or Escape keys are pressed
                    case SDLK_q:
                    case SDLK_ESCAPE:
                        quit = true;
                        break;

                    default:
                        break;
                    }
                    break;
                default:
                    break;
                }
            }
            if(number_of_gouttes !=0){
                // Si la goutte chute
                if(gouttes_list[number_of_gouttes-1]->getChute()){
                    // Si il y a collision
                    if(plan->collision(gouttes_list[number_of_gouttes-1])){

                        plan->setColliMarqueur(true);
                        //Goutte *copie = new Goutte(gouttes_list[number_of_gouttes-1]);
                        plan->setImpact(gouttes_list[number_of_gouttes-1]);

                        // On supprime l'objet Goutte dans les deux tableaux
                        /*delete gouttes_list[number_of_gouttes-1];
                        gouttes_list[number_of_gouttes-1] = NULL;
                        delete forms_list[number_of_forms-1];
                        forms_list[number_of_forms-1] = NULL;

                        // On d�cr�mente les compteurs d'objet
                        number_of_gouttes -= 1;
                        number_of_forms -= 1;*/
                    }
                }
            }

            // Update the scene
            current_time = SDL_GetTicks(); // get the elapsed time from SDL initialization (ms)
            elapsed_time = current_time - previous_time;
            if (elapsed_time > ANIM_DELAY){
                previous_time = current_time;
                update(forms_list, 1e-3 * elapsed_time); // International system units : seconds
            }

            // Render the scene
            render(forms_list, camera_position);

            // Update window screen
            SDL_GL_SwapWindow(gWindow);
        }
    }

    // Free resources and close SDL
    close(&gWindow);

    return 0;
}
