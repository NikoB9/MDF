//Variables de d�finition du plateau
const double hauteurContourPlateau = 2;
const double longueurFaceExt = 50.;//x
const double largeurFaceExt = 20.; //z
const double epaisseurFace = 0.5;
//const Color clBoard(0,0,255);
//const Color clBoardBase(255,0,0);
//const GLuint texture_sol = loadTexture("ma_texture.jpg");
